# Gsuite to Markdown.

Some tools to generate markdown files from Google Suite.
